<?php
      
      $servername ="localhost";
      $username ="id16952407_singup";
      $password ="U1\)2u%]zqw#YA-m";
      $dbname ="id16952407_singup_data";

      $conn =mysqli_connect($servername ,$username,$password,$dbname );

    //   if($conn)
    //   {
    //       echo "connection ok";
    //   }
    //   else{
    //       echo "not connected";
    //   }
?>